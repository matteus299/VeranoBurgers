// ============================================
// VERANO BURGERS — cardápio digital
// ============================================

// >>> CONFIGURAÇÃO <<<
const WHATSAPP_NUMBER = "5592995064836"; // número que recebe os pedidos (com DDI+DDD, só dígitos)

// ---------- estado do carrinho ----------
// cart = { id: { name, price, qty } }
const cart = {};

const money = (n) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

function getCartCount() {
  return Object.values(cart).reduce((sum, item) => sum + item.qty, 0);
}
function getCartTotal() {
  return Object.values(cart).reduce((sum, item) => sum + item.qty * item.price, 0);
}

// ---------- steppers no cardápio ----------
document.querySelectorAll('.stepper').forEach((stepper) => {
  const id = stepper.dataset.id;
  const productEl = stepper.closest('[data-id]');
  const name = productEl.dataset.name;
  const price = parseFloat(productEl.dataset.price);
  const qtyEl = stepper.querySelector('.step-qty');

  stepper.querySelector('.plus').addEventListener('click', () => {
    const qty = (cart[id]?.qty || 0) + 1;
    cart[id] = { name, price, qty };
    qtyEl.textContent = qty;
    syncCart();
  });

  stepper.querySelector('.minus').addEventListener('click', () => {
    if (!cart[id]) return;
    const qty = Math.max(0, cart[id].qty - 1);
    if (qty === 0) delete cart[id];
    else cart[id].qty = qty;
    qtyEl.textContent = qty;
    syncCart();
  });
});

// ---------- sincroniza toda a UI dependente do carrinho ----------
function syncCart() {
  const count = getCartCount();
  const total = getCartTotal();

  // barra flutuante
  const cartBar = document.getElementById('cartBar');
  if (count > 0) {
    cartBar.hidden = false;
    cartBar.querySelector('.cart-bar-count').textContent = count === 1 ? '1 item' : `${count} itens`;
    cartBar.querySelector('.cart-bar-total').textContent = money(total);
  } else {
    cartBar.hidden = true;
  }

  // lista dentro do sheet do carrinho
  const cartItems = document.getElementById('cartItems');
  cartItems.innerHTML = '';

  const ids = Object.keys(cart);
  if (ids.length === 0) {
    cartItems.innerHTML = '<p class="cart-item-empty">Seu pedido está vazio. Toca no + do cardápio pra adicionar.</p>';
  } else {
    ids.forEach((id) => {
      const item = cart[id];
      const row = document.createElement('div');
      row.className = 'cart-item';
      row.innerHTML = `
        <div>
          <div class="cart-item-name">${item.qty}x ${item.name}</div>
          <div class="cart-item-price">${money(item.price * item.qty)}</div>
        </div>
        <div class="stepper" data-id="${id}">
          <button class="step-btn minus" aria-label="Diminuir">–</button>
          <span class="step-qty">${item.qty}</span>
          <button class="step-btn plus" aria-label="Adicionar">+</button>
        </div>
      `;
      cartItems.appendChild(row);

      row.querySelector('.plus').addEventListener('click', () => {
        cart[id].qty += 1;
        syncAll(id);
      });
      row.querySelector('.minus').addEventListener('click', () => {
        cart[id].qty -= 1;
        if (cart[id].qty <= 0) delete cart[id];
        syncAll(id);
      });
    });
  }

  document.getElementById('cartSubtotal').textContent = money(total);
  document.getElementById('goCheckout').disabled = count === 0;

  // mantém os steppers do cardápio coerentes com o carrinho
  document.querySelectorAll('.menu-section .stepper').forEach((stepper) => {
    const id = stepper.dataset.id;
    stepper.querySelector('.step-qty').textContent = cart[id]?.qty || 0;
  });
}

// atualiza carrinho + steppers do cardápio ao mesmo tempo (usado dentro do sheet)
function syncAll(id) {
  syncCart();
}

// ---------- navegação por categoria ----------
const catButtons = document.querySelectorAll('.catnav-item');
catButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    document.getElementById(btn.dataset.target).scrollIntoView({ behavior: 'smooth' });
  });
});

const sections = document.querySelectorAll('.menu-section');
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        catButtons.forEach((b) => b.classList.toggle('is-active', b.dataset.target === entry.target.id));
      }
    });
  },
  { rootMargin: '-45% 0px -50% 0px' }
);
sections.forEach((s) => observer.observe(s));

// ---------- abrir / fechar sheets ----------
const overlay = document.getElementById('overlay');
const cartSheet = document.getElementById('cartSheet');
const checkoutSheet = document.getElementById('checkoutSheet');
const cartBar = document.getElementById('cartBar');

function openSheet(sheet) {
  overlay.hidden = false;
  sheet.hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeSheets() {
  overlay.hidden = true;
  cartSheet.hidden = true;
  checkoutSheet.hidden = true;
  document.body.style.overflow = '';
}

cartBar.addEventListener('click', () => openSheet(cartSheet));
document.getElementById('closeCart').addEventListener('click', closeSheets);
document.getElementById('closeCheckout').addEventListener('click', closeSheets);
overlay.addEventListener('click', closeSheets);

document.getElementById('goCheckout').addEventListener('click', () => {
  cartSheet.hidden = true;
  checkoutSheet.hidden = false;
});
document.getElementById('backToCart').addEventListener('click', () => {
  checkoutSheet.hidden = true;
  cartSheet.hidden = false;
});

// ---------- mostrar campo de troco só se pagamento = dinheiro ----------
const trocoField = document.getElementById('trocoField');
document.querySelectorAll('input[name="pagamento"]').forEach((radio) => {
  radio.addEventListener('change', (e) => {
    trocoField.style.display = e.target.value === 'Dinheiro' ? 'flex' : 'none';
  });
});

// ---------- montar mensagem e enviar pro WhatsApp ----------
document.getElementById('checkoutForm').addEventListener('submit', (e) => {
  e.preventDefault();

  const data = new FormData(e.target);
  const nome = data.get('nome').trim();
  const telefone = data.get('telefone').trim();
  const rua = data.get('rua').trim();
  const bairro = data.get('bairro').trim();
  const complemento = data.get('complemento').trim();
  const referencia = data.get('referencia').trim();
  const pagamento = data.get('pagamento');
  const troco = data.get('troco').trim();
  const observacoes = data.get('observacoes').trim();

  const linhas = [];
  linhas.push('🍔 *NOVO PEDIDO — VERANO BURGERS*');
  linhas.push('');
  linhas.push('*Itens:*');
  Object.values(cart).forEach((item) => {
    linhas.push(`• ${item.qty}x ${item.name} — ${money(item.price * item.qty)}`);
  });
  linhas.push('');
  linhas.push(`*Subtotal:* ${money(getCartTotal())}`);
  linhas.push('');
  linhas.push(`*Cliente:* ${nome}`);
  linhas.push(`*Telefone:* ${telefone}`);
  linhas.push(`*Endereço:* ${rua} - ${bairro}`);
  if (complemento) linhas.push(`*Complemento:* ${complemento}`);
  if (referencia) linhas.push(`*Referência:* ${referencia}`);
  linhas.push(`*Pagamento:* ${pagamento}${pagamento === 'Dinheiro' && troco ? ` (troco para ${troco})` : ''}`);
  if (observacoes) linhas.push(`*Observações:* ${observacoes}`);

  const mensagem = linhas.join('\n');
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensagem)}`;
  window.location.href = url;
});

// ---------- inicial ----------
syncCart();
