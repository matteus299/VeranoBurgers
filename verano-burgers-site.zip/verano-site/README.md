# Verano Burgers — Cardápio Digital

Site estático (HTML/CSS/JS puro, sem framework, sem back-end) que funciona como
catálogo virtual: o cliente monta o pedido, preenche os dados de entrega e o
site já abre o WhatsApp com a mensagem pronta pra enviar direto pra você.

Custo de hospedagem: **R$ 0** (plano free da Vercel aguenta esse tráfego numa boa).
Único custo real é o domínio, se você quiser um `.com` ou `.com.br` próprio.

---

## 1. Testar localmente antes de publicar

Não precisa de nada instalado. Só abra o arquivo `index.html` no navegador
(duplo clique) ou, se quiser testar como fica no celular, suba a pasta pro
GitHub e siga direto pro passo 2 — o preview da Vercel já é o suficiente.

---

## 2. Publicar na Vercel (grátis)

**Passo a passo:**

1. Crie uma conta no [github.com](https://github.com) (se ainda não tiver).
2. Crie um repositório novo, por exemplo `verano-burgers-site`.
3. Suba todos os arquivos desta pasta pro repositório (pode arrastar e soltar
   os arquivos direto na interface do GitHub, em "Add file" → "Upload files").
4. Crie uma conta em [vercel.com](https://vercel.com) usando login do GitHub.
5. No painel da Vercel, clique em **"Add New" → "Project"**.
6. Selecione o repositório `verano-burgers-site`.
7. Não precisa mexer em nenhuma configuração — é um site estático puro.
   Clique em **"Deploy"**.
8. Em ~30 segundos a Vercel te dá um link tipo
   `https://verano-burgers-site.vercel.app` — já funcionando, já pode testar
   no celular.

Sempre que você editar algo e subir de novo pro GitHub, a Vercel atualiza o
site sozinha, automaticamente.

---

## 3. Colocar seu próprio domínio

1. Compre o domínio onde preferir (Registro.br pra `.com.br`, ou GoDaddy /
   Namecheap / Hostinger pra `.com`). Domínio `.com.br` costuma sair mais
   barato e passa mais confiança pro cliente de Manaus.
2. No painel do projeto na Vercel, vá em **Settings → Domains**.
3. Digite seu domínio (ex: `veranoburgers.com.br`) e clique em **Add**.
4. A Vercel mostra 1-2 registros de DNS pra você cadastrar no painel do seu
   domínio (geralmente um registro tipo `A` ou `CNAME`). Copie exatamente o
   que ela mostrar.
5. Cola esses registros no painel do site onde comprou o domínio (Registro.br,
   etc.). Pode levar de alguns minutos até 24h pra propagar, mas geralmente
   é rápido.
6. Pronto — seu link vira `https://veranoburgers.com.br` e é pra esse link
   que você manda o tráfego pago.

---

## 4. Como o pedido chega pra você

Quando o cliente aperta **"Enviar pedido no WhatsApp"**, o site abre o
WhatsApp (app ou web, dependendo do aparelho) já com uma mensagem pronta,
formatada assim:

```
🍔 NOVO PEDIDO — VERANO BURGERS

Itens:
• 2x Combo 1 · X-Salada — R$ 77,80
• 1x X-Bacon — R$ 28,50

Subtotal: R$ 106,30

Cliente: Maria Silva
Telefone: (92) 9 9999-9999
Endereço: Rua Exemplo, 123 - Bairro Tal
Complemento: Apto 4
Referência: Perto do mercado
Pagamento: Dinheiro (troco para R$ 150,00)
Observações: Sem cebola
```

O cliente só precisa apertar "Enviar" dentro do próprio WhatsApp — o site não
manda nada sozinho, quem confirma o envio é sempre o cliente.

**O número que recebe os pedidos está configurado como `+55 92 99506-4836`.**
Se um dia precisar trocar, o único lugar que precisa mexer é a primeira linha
do arquivo `js/app.js`:

```js
const WHATSAPP_NUMBER = "5592995064836";
```

---

## 5. Editar preços, produtos ou textos

Tudo fica no `index.html`, dentro de blocos `<article class="product">...`.
Pra mudar um preço, por exemplo, edite dois lugares no mesmo bloco (tem que
bater os dois):

```html
<article class="product" data-id="combo1" data-name="Combo 1 · X-Salada" data-price="38.90">
  ...
  <span class="price">R$ 38,90</span>
  ...
```

- `data-price` → usado pelo JavaScript pra calcular o total (formato com ponto: `38.90`)
- `<span class="price">` → o que aparece na tela pro cliente (formato com vírgula: `R$ 38,90`)

Pra adicionar um produto novo, copie um bloco `<article class="product">...</article>`
inteiro, cole embaixo do último da mesma categoria, e troque nome/preço/imagem.

Fotos ficam em `assets/`. Pra trocar a foto de um produto, basta substituir o
arquivo com o mesmo nome, ou trocar o caminho no `src=""` da tag `<img>`.

---

## 6. Estrutura dos arquivos

```
verano-burgers-site/
├── index.html          → estrutura da página e todos os produtos
├── css/style.css        → todo o visual (cores, fontes, layout)
├── js/app.js             → carrinho, checkout e integração com WhatsApp
├── assets/                → logo e fotos dos produtos
└── README.md              → este guia
```

Qualquer edição é só nesses arquivos — não tem build, não tem instalação,
não tem servidor pra manter no ar.
